#! /bin/bash 

# 从单词表中依次取单词然后打印到终端: 遍历单词表
i=1
for file in my name is wang 
do
	echo "word $i: $file"
	i=$(expr $i + 1)
done



# 遍历当前目录下的文件
num=1
num_re=0
for dir_file in `ls`
do
	#echo " file $num: $dir_file"
	if [ -f $dir_file ]
	then
		echo " $dir_file is a regular file"
		let num_re++
	else
		echo " $dir_file is a not regular file"
	fi
	let num++
done

echo " regular is $num_re "
echo " file is $num "
