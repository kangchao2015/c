#! /bin/bash 

var_local()
{
  local	var1=10
	var2=20
	echo "in var_local"
	echo "var1=$var1"
	echo "var2=$var2"
}

var_local
echo "in main"
	echo "var1=$var1"
	echo "var2=$var2"


