#! /bin/bash 

i=3

echo "i= $i"
unset i

echo "i= $i"

# 系统变量
echo " 系统变量:"
echo "HOME = $HOME" 

#user var
echo "user var :"
myVar=10
echo "myVar is $myVar"

# pos var
echo " pos var:"
echo "\$0 is $0"
echo " the first argment is $1"
echo " the second argment is $2"
echo " the 3 argment is $3"
echo " the 4 argment is $4"
echo " the 5 argment is $5"
echo " the 6 argment is $6"

# pre pos 
echo "pre pos :"
echo "\$# the number of line arg is $#"
echo "the pid is $$"


