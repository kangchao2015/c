#! /bin/bash 

read var1 var2

echo "var1 is $var1"
echo 
echo "var2 is $var2"
