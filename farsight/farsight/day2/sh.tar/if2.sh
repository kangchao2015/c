#! /bin/bash 

read var
if [ $var -eq 30 ]
then
	echo " the value of var is = 30"
else
	echo " the value of var is not equal 30"
fi
