#! /bin/bash 

#while 表达式
#do
#   命令表
#done

i=1

while [ $i -le 8 ]
do
	if [ $i -eq 5 ]
	then
		let i++
		continue
	fi
	touch file$i
	i=`expr $i + 1`

done


