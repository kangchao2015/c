#! /bin/bash 

read -p "plz input a value" var
#echo  -n "plz input a value"
# read var

if [ $var -gt 30 ]
then
	echo " $var is great than 30"
elif [ $var -lt 30 ]
then
	echo " $var is less than 30"
else
	echo " $var is equal 30"
fi

