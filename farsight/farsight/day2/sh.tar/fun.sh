#! /bin/bash 

check_user()
{
	user=`who | grep "\<$1\>" | wc -l`
	if [ $user -eq 0 ]
	then
		return 0
	else
		return 1
	fi
}

while true
do
	read -p " plz input username>> " username
	check_user $username
	if [ $? -eq 0 ] 
	then
		echo " $username is longout"
	else
		echo "$username is login"
	fi
done
