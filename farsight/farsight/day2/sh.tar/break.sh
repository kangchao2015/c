#! /bin/bash 

i=1
while [ $i -le 10 ]
do
	echo "i = $i"
	let i++
	if [ $i -eq 8 ]
	then
		echo " $i is 8 we will break loop"
		break
	fi
done
