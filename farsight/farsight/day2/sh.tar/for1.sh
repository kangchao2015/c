#! /bin/bash 

for file 
do
	echo "$file"
done
