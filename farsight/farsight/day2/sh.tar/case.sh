#! /bin/bash 

case $1 in
	file1)
		echo "you select file1"
		;;
	file2)
		echo "you select file2"
		;;
	file3 | file4)
		echo "you select file3 or file4"
		;;
	fi?)
		echo "you select fi? "
		;;
	3)
		echo "you select 3"
		;;
	*)
		echo "you not select file1 or file2 or file3 or file4"
		;;
esac
