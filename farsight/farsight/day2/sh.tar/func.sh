#! /bin/bash 

#先定义函数再调用
expr_num()
{
	expr $1 + $2
	return 3
}

sum=`expr_num 3 5` #这种方式保存的是函数中的输出信息
echo "sum = $sum"

expr_num 5 6
echo $?
