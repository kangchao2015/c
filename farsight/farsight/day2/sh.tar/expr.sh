#! /bin/bash 

#从终端输入4个数，进行 var1*var2+var3\var4-var1%var3
#2 4 6 8   2*4+6\8-1%6

#sum=`expr 2 \* 4 + 6 / 8 - 2 % 6`
sum=$(expr 2 \* 4 + 6 / 8 - 2 % 6)
echo "sum = $sum"

read  var1 var2 var3 var4
sum=`expr $var1 \* $var2 + $var3 / $var4 - $var1 % $var3`
echo "sum = $sum"

echo -n "plz 4 个 数据"# -n 不换行
read v1 v2 v3 v4
echo "$v1 ,$v2 ,$v3 , $v4"
