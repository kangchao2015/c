#! /bin/bash 

#通过命令行传参的方式来判断文件的类型
# test <==> [ ]

if test $# -ne 1
then
	echo "Usage: $0 filename"
	exit 0 
fi

if test -L $1
then
	echo "文件$1 is a link file"
fi

if [ -f $1 ]
then
	echo "文件$1 is a regular file"
fi

if [ -d $1 ]
then
	echo "文件$1 is a 目录 file"
fi

if [ -p $1 ]
then
	echo "文件$1 is a pipe file"
fi
