#! /bin/bash 

echo "today is `date`"

